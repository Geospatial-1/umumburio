document.addEventListener('DOMContentLoaded', () => {
  console.log("Umumburio Group Management System loaded.");
});
